CREATE DATABASE HomeworkDB;
GO

USE HomeworkDB;

CREATE TABLE tblStudentInfo (
    StudentID INT IDENTITY PRIMARY KEY,
    FullName NVARCHAR(100),
    BirthDate DATE,
    City NVARCHAR(50),
    Age INT,
    EnrollYear INT,
    Major NVARCHAR(50),
    GPA DECIMAL(3,2)
);

INSERT INTO tblStudentInfo
VALUES
(N'Nguyen Van A','2002-01-01',N'HCM',22,2020,N'IT',3.2),
(N'Tran Thi B','2001-05-10',N'Hanoi',23,2019,N'CS',3.6);

