﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace StudentManager_HW
{
    public partial class Form1 : Form
    {
        string connectionString;

        public Form1()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["HomeworkDBConnection"].ConnectionString;

        }


        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter da =
                    new SqlDataAdapter("SELECT * FROM tblStudentInfo", conn);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvStudentInfo.DataSource = dt;
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void dgvStudentInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow r = dgvStudentInfo.Rows[e.RowIndex];

                txtFullName.Text = r.Cells["FullName"].Value.ToString();
                txtCity.Text = r.Cells["City"].Value.ToString();
                txtAge.Text = r.Cells["Age"].Value.ToString();
                txtEnrollYear.Text = r.Cells["EnrollYear"].Value.ToString();
                txtMajor.Text = r.Cells["Major"].Value.ToString();
                txtGPA.Text = r.Cells["GPA"].Value.ToString();
                dtpBirthDate.Value = Convert.ToDateTime(r.Cells["BirthDate"].Value);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO tblStudentInfo VALUES (@n,@b,@c,@a,@y,@m,@g)", conn);

                cmd.Parameters.AddWithValue("@n", txtFullName.Text);
                cmd.Parameters.AddWithValue("@b", dtpBirthDate.Value);
                cmd.Parameters.AddWithValue("@c", txtCity.Text);
                cmd.Parameters.AddWithValue("@a", int.Parse(txtAge.Text));
                cmd.Parameters.AddWithValue("@y", int.Parse(txtEnrollYear.Text));
                cmd.Parameters.AddWithValue("@m", txtMajor.Text);
                cmd.Parameters.AddWithValue("@g", decimal.Parse(txtGPA.Text));

                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(
        dgvStudentInfo.CurrentRow.Cells["StudentID"].Value);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(
                    "UPDATE tblStudentInfo SET FullName=@n WHERE StudentID=@id", conn);

                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@n", txtFullName.Text);

                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(
        dgvStudentInfo.CurrentRow.Cells["StudentID"].Value);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlCommand cmd =
                    new SqlCommand("DELETE FROM tblStudentInfo WHERE StudentID=@id", conn);

                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFullName.Clear();
            txtCity.Clear();
            txtAge.Clear();
            txtEnrollYear.Clear();
            txtMajor.Clear();
            txtGPA.Clear();
            dtpBirthDate.Value = DateTime.Now;
        }
    }
}
